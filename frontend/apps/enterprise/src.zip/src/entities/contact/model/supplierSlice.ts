import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import api from "@/shared/api/api";
import { RootState } from '@/app/store/store';
import { Supplier } from "@vignesh-erp/shared-kernel";

const API_URL = "/purchases/suppliers";

interface SupplierState {
    suppliers: Supplier[];
    supplier: Supplier | null;
    isLoading: boolean;
    isSuccess: boolean;
    isError: boolean;
    message: string;
    stats: { _id: string, supplierName: string, totalAmount: number, billCount: number }[];
}

// Redux State Interface

const initialState: SupplierState = {
    suppliers: [],
    supplier: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
    message: '',
    stats: [],
};

// Get all suppliers
export const getAllSuppliers = createAsyncThunk<Supplier[], void, { state: RootState, rejectValue: string }>(
    'suppliers/getAll',
    async (_, thunkAPI) => {
        try {
            const response = await api.get(API_URL);
            return response.data.data || response.data; // Handle wrapped response
        } catch (error: any) {
            const message = error.response?.data?.message || error.message || error.toString();
            return thunkAPI.rejectWithValue(message);
        }
    }
);

// Get supplier by ID
export const getSupplierById = createAsyncThunk<Supplier, string | { id: string, branchId?: string }, { state: RootState, rejectValue: string }>(
    'suppliers/getById',
    async (arg, thunkAPI) => {
        try {
            const id = typeof arg === 'string' ? arg : arg.id;
            const branchId = typeof arg === 'object' ? arg.branchId : undefined;

            // Construct URL with optional branchId
            let url = `${API_URL}/${id}`;
            if (branchId) {
                url += `?branchId=${branchId}`;
            }

            const response = await api.get(url);
            return response.data.data || response.data;
        } catch (error: any) {
            const message = error.response?.data?.message || error.message || error.toString();
            return thunkAPI.rejectWithValue(message);
        }
    }
);

// Add supplier
export const addSupplier = createAsyncThunk<Supplier, Partial<Supplier>, { state: RootState, rejectValue: string }>(
    'suppliers/add',
    async (supplierData, thunkAPI) => {
        try {
            const response = await api.post(API_URL, supplierData);
            return response.data.data || response.data;
        } catch (error: any) {
            const message = error.response?.data?.message || error.message || error.toString();
            return thunkAPI.rejectWithValue(message);
        }
    }
);

// Update supplier
export const updateSupplier = createAsyncThunk<Supplier, { id: string, supplierData: Partial<Supplier> }, { state: RootState, rejectValue: string }>(
    'suppliers/update',
    async ({ id, supplierData }, thunkAPI) => {
        try {
            const response = await api.put(`${API_URL}/${id}`, supplierData);
            return response.data.data || response.data;
        } catch (error: any) {
            const message = error.response?.data?.message || error.message || error.toString();
            return thunkAPI.rejectWithValue(message);
        }
    }
);

// Delete supplier
export const deleteSupplier = createAsyncThunk<string, string, { state: RootState, rejectValue: string }>(
    'suppliers/delete',
    async (id, thunkAPI) => {
        try {
            await api.delete(`${API_URL}/${id}`);
            return id;
        } catch (error: any) {
            const message = error.response?.data?.message || error.message || error.toString();
            return thunkAPI.rejectWithValue(message);
        }
    }
);

// Get Supplier Analytics (Replaces getAllSuppliers and getStats for dashboard)
export const getSupplierAnalytics = createAsyncThunk<Supplier[], void, { state: RootState, rejectValue: string }>(
    'suppliers/getAnalytics',
    async (_, thunkAPI) => {
        try {
            const response = await api.get(`${API_URL}/analytics`);
            return response.data.data;
        } catch (error: any) {
            const message = (error.response?.data?.message) || error.message || error.toString();
            return thunkAPI.rejectWithValue(message);
        }
    }
);

// Get Supplier Stats
export const getSupplierStats = createAsyncThunk<{ _id: string, supplierName: string, totalAmount: number, billCount: number }[], void, { state: RootState, rejectValue: string }>(
    'suppliers/getStats',
    async (_, thunkAPI) => {
        try {
            const response = await api.get('/api/purchases/stats/supplier-totals');
            return response.data;
        } catch (error: any) {
            const message = (error.response?.data?.message) || error.message || error.toString();
            return thunkAPI.rejectWithValue(message);
        }
    }
);

export const supplierSlice = createSlice({
    name: 'suppliers',
    initialState,
    reducers: {
        reset: (state) => {
            state.isLoading = false;
            state.isSuccess = false;
            state.isError = false;
            state.message = '';
        },
        clearSupplier: (state) => {
            state.supplier = null;
        },
        setSelectedSupplier: (state, action: PayloadAction<Supplier | null>) => {
            state.supplier = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder
            // Get all suppliers
            .addCase(getAllSuppliers.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(getAllSuppliers.fulfilled, (state, action) => {
                state.isLoading = false;
                state.isSuccess = true;
                state.suppliers = action.payload;
            })
            .addCase(getAllSuppliers.rejected, (state, action) => {
                state.isLoading = false;
                state.isError = true;
                state.message = action.payload as string;
            })
            // Get supplier by ID
            .addCase(getSupplierById.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(getSupplierById.fulfilled, (state, action) => {
                state.isLoading = false;
                state.isSuccess = true;
                state.supplier = action.payload;
            })
            .addCase(getSupplierById.rejected, (state, action) => {
                state.isLoading = false;
                state.isError = true;
                state.message = action.payload as string;
            })
            // Add supplier
            .addCase(addSupplier.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(addSupplier.fulfilled, (state, action) => {
                state.isLoading = false;
                state.isSuccess = true;
                state.suppliers.push(action.payload);
            })
            .addCase(addSupplier.rejected, (state, action) => {
                state.isLoading = false;
                state.isError = true;
                state.message = action.payload as string;
            })
            // Update supplier
            .addCase(updateSupplier.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(updateSupplier.fulfilled, (state, action) => {
                state.isLoading = false;
                state.isSuccess = true;
                state.suppliers = state.suppliers.map((supplier) =>
                    supplier._id === action.payload._id ? action.payload : supplier
                );
                state.supplier = action.payload;
            })
            .addCase(updateSupplier.rejected, (state, action) => {
                state.isLoading = false;
                state.isError = true;
                state.message = action.payload as string;
            })
            // Delete supplier
            .addCase(deleteSupplier.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(deleteSupplier.fulfilled, (state, action) => {
                state.isLoading = false;
                state.isSuccess = true;
                state.suppliers = state.suppliers.filter(
                    (supplier) => supplier._id !== action.payload
                );
            })
            .addCase(deleteSupplier.rejected, (state, action) => {
                state.isLoading = false;
                state.isError = true;
                state.message = action.payload as string;
            })
            // Get Stats
            .addCase(getSupplierStats.fulfilled, (state, action) => {
                state.stats = action.payload;
            })
            // Get Analytics
            .addCase(getSupplierAnalytics.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(getSupplierAnalytics.fulfilled, (state, action) => {
                state.isLoading = false;
                state.isSuccess = true;
                state.suppliers = action.payload; // Populates suppliers with enriched data
            })
            .addCase(getSupplierAnalytics.rejected, (state, action) => {
                state.isLoading = false;
                state.isError = true;
                state.message = action.payload as string;
            });
    },
});

export const { reset, clearSupplier, setSelectedSupplier } = supplierSlice.actions;
export default supplierSlice.reducer;
